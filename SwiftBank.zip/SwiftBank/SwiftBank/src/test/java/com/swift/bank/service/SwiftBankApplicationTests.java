package com.swift.bank.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwiftBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
